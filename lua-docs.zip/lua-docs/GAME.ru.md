# Игра, игрок и время

Функции игрового состояния возвращают актуальные значения, когда соответствующие игровые данные доступны.

## Игра `game`

- `game.map() -> string` — имя текущей карты.
- `game.in_menu() -> boolean` — открыто ли главное меню клиента.
- `game.warmup() -> boolean` — значение `m_bWarmupPeriod`.
- `game.freeze_time() -> boolean` — значение `m_bFreezePeriod`.
- `game.bomb_planted() -> boolean` — значение `m_bBombPlanted`.
- `game.rounds_played() -> integer` — `m_totalRoundsPlayed`.
- `game.round_time_left() -> number?` — значение, вычисленное из начала и длительности раунда; может не вернуть значение при отсутствии данных.
- `game.match_started() -> boolean` — значение `m_bHasMatchStarted`.

## Счётчики и время `globals`

`globals.tickcount() -> integer` и `globals.framecount() -> integer` возвращают номер тика и кадра. Также доступны `curtime()`, `realtime()`, `frametime()` и `interval()` для времени и длительности кадра.

## Локальный игрок

`entity.local_pawn() -> wl.entity?` возвращает userdata или `nil`. Следующие методы расширения принимают `self` через двоеточие:

- `player:flags() -> integer` — флаги `C_BaseEntity::m_fFlags`; если поле не найдено, возвращается 0.
- `player:on_ground() -> boolean` — проверяет младший бит флагов; если поле не найдено, возвращает false.
- `player:scoped() -> boolean` — состояние прицела; false при недоступном поле.
- `player:health()`, `player:armor()`, `player:team()`, `player:alive()`, `player:velocity()`, `player:origin()` — зарегистрированы. Подробности и наблюдаемые аргументы — в индексе.
- `player:weapons()`, `player:weapon_info()`, `player:hitboxes()`, `player:hitbox(...)`, `player:avatar(...)` возвращают оружие, сведения о нём, хитбоксы и аватар игрока.

```lua
local player = entity.local_pawn()
if player and player:alive() and player:on_ground() then
    print("player is on ground")
end
```

## Дополнительные поля команды

`cmd:upmove() -> number`, `cmd:set_upmove(number)` — вертикальное движение, запись ограничивает диапазон -1..1 при доступных данных. `cmd:predicted() -> boolean` читает состояние predicted. `cmd:tick() -> integer` возвращает счётчик или 0 при отсутствии данных. `cmd:mouse_delta() -> number, number` возвращает два накопленных значения. Все эти методы требуют действительного объекта в callback `createmove`.
