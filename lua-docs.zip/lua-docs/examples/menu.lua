-- Пример вызова UI, выведенный из DLL. Не проверен в игре.
local page = ui.tab("Example")
local enabled = page.checkbox("Enabled", false)
local volume = page.slider_int("Value", 0, 100, 50)
local mode = page.combo("Mode", { "First", "Second" }, 0)

page.button("Print values", function()
    local index, name = mode:get()
    print("enabled:", enabled:get(), "value:", volume:get(), "mode:", index, name)
end)
