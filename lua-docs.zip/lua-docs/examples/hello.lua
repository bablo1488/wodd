-- Минимальный скрипт. Вывод зависит от настроек клиента.
print("Lua script loaded")

local count = 0
client.delay(1.0, function()
    count = count + 1
    print("Delayed callback:", count)
end)
