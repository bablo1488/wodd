-- Full Stop
-- Тормозит локального игрока на земле, пока удерживается attack.
-- Положи файл в папку Lua-скриптов клиента и загрузи его.

local STOP_SPEED = 8.0 -- На меньшей скорости сбрасываем остаточный ввод.

local function is_vector(v)
    return v ~= nil
        and type(v.x) == "number"
        and type(v.y) == "number"
end

events.on("createmove", function(cmd)
    if not cmd or not cmd:has(buttons.attack) then
        return
    end

    local player = entity.local_pawn()
    if not player or not player:alive() or not player:on_ground() then
        return
    end

    local velocity = player:velocity()
    local angles = cmd:view_angles()
    if not is_vector(velocity) or not is_vector(angles) then
        return
    end

    local vx, vy = velocity.x, velocity.y
    local speed = math.sqrt(vx * vx + vy * vy)
    if speed <= STOP_SPEED then
        -- Убираем остаточное движение на почти нулевой скорости.
        cmd:set_move(0, 0, true)
        return
    end

    -- Переводим противоположную скорость из мировых координат
    -- в локальные оси forward/side относительно угла камеры.
    local yaw = math.rad(angles.y)
    local forward = -(vx * math.cos(yaw) + vy * math.sin(yaw))
    local side = vx * math.sin(yaw) - vy * math.cos(yaw)

    -- Нормализуем направление, сохраняя его при диагональном торможении.
    local scale = math.max(math.abs(forward), math.abs(side))
    if scale > 0 then
        forward = forward / scale
        side = side / scale
    end

    -- true синхронизирует кнопки движения с заданными осями.
    cmd:set_move(forward, side, true)
end)
