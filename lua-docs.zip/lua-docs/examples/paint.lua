-- Пример отрисовки, выведенный из DLL. Не проверен в игре.
local white = { r = 255, g = 255, b = 255, a = 255 }
local cyan = { r = 0, g = 180, b = 230, a = 255 }

events.on("paint", function()
    render.line(100, 100, 300, 100, white, 1)
    render.line(100, 110, 220, 110, cyan, 2)
end)
