-- Демонстрация объекта команды; сама по себе движения не меняет.
-- Выведено из кода DLL, в игре не проверено.
events.on("createmove", function(cmd)
    local forward, side = cmd:move()
    if forward == nil or side == nil then return end
    -- Использовать forward и side здесь, внутри callback.
end)
