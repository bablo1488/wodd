-- Проверено с LuaJIT и встроенными в DLL Lua-реализациями типов.
local velocity = vector(3, 4, 0)
print("Speed 2D:", velocity:length2d())

local tint = color("#00b4e6ff")
print("Color:", tint:hex())

local text = json.encode({ enabled = true, label = "demo" })
local data, err = json.decode(text)
if not data then
    print("JSON error:", err)
else
    print("JSON label:", data.label)
end
