# Трассировка и оценка попаданий

 Там, где методы проверяют контекст, вызывайте их только внутри `createmove`, `frame_stage` или обработчика игрового события. Объекты сущностей и доступность игровых систем могут меняться при обновлении игры.

## `trace.line`

`trace.line(start: vector, finish: vector, options?: wl.entity | table) -> table` читает две таблицы координат `{x, y, z}` и необязательный фильтр. Если вместо таблицы передан `wl.entity`, он используется как исключаемая сущность. Если передана таблица, обработчик читает:

| Поле | Тип | Назначение |
|---|---|---|
| `skip` | `wl.entity?` | Исключаемая сущность. |
| `mask` | number? | Маска, по умолчанию 1847299. |
| `layer` | number? | Слой, по умолчанию 4. |
| `type` | number? | Тип фильтра, по умолчанию 7. |
| `mins`, `maxs` | vector? | Границы формы для расширенного варианта. |

Результат содержит `hit: boolean`, `fraction: number`, `position: vector`, `normal: vector`, `entity: wl.entity?`. Расширенный обработчик также формирует `start_solid: boolean` и `friction: number`. Поля `position` и `normal` — векторы `{x, y, z}`.

```lua
-- Пример трассировки луча.
events.on("createmove", function(cmd)
    local player = entity.local_pawn()
    if not player then return end
    local from = player:eye_position()
    if not from then return end
    local to = { x = from.x + 100, y = from.y, z = from.z }
    local hit = trace.line(from, to, player)
    if hit and hit.hit then print("Trace hit") end
end)
```

## `trace.hull`

`trace.hull(start, finish, mins, maxs, options?) -> table` читает четыре вектора и фильтр той же формы, что и `trace.line`. Результат расширенного обработчика: `hit`, `fraction`, `position`, `normal`, `entity`, `start_solid`, `friction`. По умолчанию используются маска по умолчанию 1839107, слой 4, тип 7; при наличии параметров фильтра берутся их значения.

## Урон и препятствия

- `trace.damage(target: wl.entity, position: vector, hitgroup?: integer, start?: vector) -> number?` — функция читает цель, точку, необязательную группу попадания (по умолчанию 1) и необязательную начальную точку. Может не вернуть значение, если необходимые игровые данные недоступны.
- `trace.bullet(start: vector, finish: vector, target?: wl.entity, hitgroup?: integer) -> table?` — два вектора, необязательная цель и группа попадания (по умолчанию 2, если цель задана). При недостатке данных или нулевой длине может не вернуть результат. Таблица содержит `hit`, `entity`, `damage`, `penetrated`, `position`, `range`; при переданной цели также `target_damage`, `target_hit`.
- `trace.can_penetrate(start: vector, finish: vector) -> boolean?` — при отсутствии игровых данных или нулевой длине может не вернуть значение.
- `trace.scale_damage(amount: number, hitgroup: integer, target: wl.entity) -> number` — читает число, группу и цель; точную игровую модель и поведение без локального игрока требуется проверить.
- `trace.smoke(start: vector, finish: vector) -> boolean, number` — два вектора; возвращает логическое и числовое значения. Смысл второго результата и контекст использования требуют практической проверки.

`trace.mask` содержит зарегистрированные имена `visible`, `shot`, `player`; точные числовые значения следует вывести из работающего клиента, если они необходимы. Различные типы трассировок и данные игрока зависят от текущей версии игры.
