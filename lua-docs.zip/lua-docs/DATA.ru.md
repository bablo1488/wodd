# Хранение данных, файлы и HTTP

Работа с сохранёнными данными, файлами, настройками, HTTP и JSON.

## Локальная база `db`

`db.save(name, value)` кодирует значение в JSON и записывает его. `db.load(name, default)` читает JSON и возвращает `default`, если файл отсутствует или декодер вернул `nil`. Имена БД ограничены буквами, цифрами, `_` и `-`.

```lua
local defaults = { enabled = false, count = 0 }
local state = db.load("my_script", defaults)
state.count = state.count + 1
db.save("my_script", state)
```

Функции, userdata и циклические таблицы не являются надёжно сериализуемыми JSON-значениями. Не сохраняйте объекты команд и сущностей.

## Конфигурация `config`

`config.get(key: string)` ищет значение по ключу и возвращает типизированное значение или `nil` при отсутствии. Значение может быть логическим, числом, строкой или списком чисел/логических значений. `config.set(key: string, value)` принимает boolean, число, строку или список; `config.keys()` возвращает доступные ключи настроек. Не меняйте неизвестные ключи без понимания того, какую настройку они контролируют.

## Файлы `file` и insecure

Раздел `file` создаётся только при включённом insecure для скрипта. Имя — непустой относительный путь внутри `C:\neverlose\scripts\data`. Реализация переводит `/` в `\` и отвергает `..`, `:`, а также ведущий `\`.

- `file.read(name)` возвращает содержимое строкой; при невозможности открыть — `nil, "cannot open"`.
- `file.write(name, contents)` записывает строку и возвращает boolean состояния потока; создаёт родительские каталоги.
- `file.append(name, contents)` добавляет строку и возвращает boolean состояния потока.
- `file.exists(name)` возвращает boolean.
- `file.remove(name)` возвращает boolean результата.
- `file.list(name?)` без аргумента использует корневую папку data; при аргументе применяются те же правила имени. Возвращает список имён файлов и папок.

```lua
-- Требуется разрешение insecure.
local ok = file.write("example/hello.txt", "hello\n")
if ok then
    local text, err = file.read("example/hello.txt")
    if text then print(text) else print(err) end
end
```

## HTTP

Доступен только при разрешении insecure. `http.get(url, options?, callback)` и `http.post(url, body, options?, callback)` читают строковый URL, для POST — строковое тело, необязательную таблицу и функцию. Поля options: `headers` — таблица строковых заголовков; `timeout` — секунды, ограничение 1–30, по умолчанию 10. При перегрузке очереди возвращается `false, "too many requests running"`; формат callback описан ниже. Не отправляйте персональные данные или токены в чужие скрипты.

## Утилиты

`utils.base64_encode(text)` и `utils.base64_decode(text)` читают строку; декодер проверяет символы. `utils.fnv1a(text)` и `utils.murmur2(text)` читают строку и вычисляют хеш. Тип возвращаемого значения и дополнительные особенности нужно подтвердить запуском. `utils.clipboard_get()` и `utils.clipboard_set(text)` требуют разрешения insecure.

### Ответ HTTP

Диспетчер результатов вызывает сохранённый callback с **одной таблицей**:

| Поле | Тип | Значение |
|---|---|---|
| `ok` | boolean | Успешно ли завершился запрос. |
| `status` | integer | HTTP-статус из результата. |
| `body` | string | Тело ответа, может содержать бинарные данные. |
| `error` | string? | Сообщение об ошибке, если запрос завершился неудачно. |
| `headers` | table<string, string> | Полученные заголовки. |

`http.get(url, callback)` и `http.get(url, options, callback)` ставят GET в очередь; `http.post(url, body, callback)` и `http.post(url, body, options, callback)` — POST. При успешной постановке функция возвращает `true`; при переполненной очереди — `false, "too many requests running"`. Реализация проверяет схему `http://`/`https://`; размер ответа ограничен 8 МБ. Ответ callback передаётся при обслуживании очереди клиента, если скрипт ещё загружен.

```lua
-- Требуется разрешение insecure.
local queued, err = http.get("https://example.com", function(response)
    if response.ok then
        print("HTTP", response.status, "bytes", #response.body)
    else
        print("HTTP error", response.error or response.status)
    end
end)
if not queued then print(err) end
```

