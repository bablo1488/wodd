---@meta
-- ИНДЕКС ИМЁН, НЕ ЗАПУСКАТЬ. Аргументы (...) означают: сигнатура не восстановлена.
-- Доступность, контекст и результат требуют проверки. Для ручных сигнатур см. api.lua.

---@class WLIndex_events
local events = {}
--- Реализация sub_18004EE00. Сигнатура не определена.
---@param ... any
---@return any
function events.on(...) end
--- Реализация sub_18004F020. Сигнатура не определена.
---@param ... any
---@return any
function events.off(...) end
---@type WLIndex_events
events = nil

---@class WLIndex_metatable_wl_event
local metatable_wl_event = {}
--- Реализация sub_18004F120. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:name(...) end
--- Реализация sub_18004F160. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_int(...) end
--- Реализация sub_18004F1E0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_float(...) end
--- Реализация sub_18004F260. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_bool(...) end
--- Реализация sub_18004F2F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_string(...) end
--- Реализация sub_18004F3B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_controller(...) end
--- Реализация sub_18004F470. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_event:get_pawn(...) end

---@class WLIndex_metatable_wl_entity
local metatable_wl_entity = {}
--- Реализация sub_18004F680. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:address(...) end
--- Реализация sub_18004F6F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:class_name(...) end
--- Реализация sub_18004F7A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:health(...) end
--- Реализация sub_18004F7F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:armor(...) end
--- Реализация sub_18004F840. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:team(...) end
--- Реализация sub_18004F8A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:alive(...) end
--- Реализация sub_18004F910. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:name(...) end
--- Реализация sub_18004F9A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:origin(...) end
--- Реализация sub_18004FAC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:velocity(...) end
--- Реализация sub_18004FBD0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:eye_position(...) end
--- Реализация sub_18004FD20. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:eye_angles(...) end
--- Реализация sub_18004FE30. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:aim_punch(...) end
--- Реализация sub_18004FF40. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:bone(...) end
--- Реализация sub_180050050. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:pawn(...) end
--- Реализация sub_180050100. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:weapon(...) end
--- Реализация sub_1800501D0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:is_enemy(...) end
--- Реализация sub_1800502D0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:is_local(...) end
--- Реализация sub_180050BF0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:get(...) end
--- Реализация sub_180050C70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:set(...) end
--- Реализация sub_18005EB90. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:steam_id(...) end
--- Реализация sub_18005EC40. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:ping(...) end
--- Реализация sub_18005ECB0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:money(...) end
--- Реализация sub_18005ED60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:observer_target(...) end
--- Реализация sub_18005EE60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:bbox(...) end
--- Реализация sub_18005F0E0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:vdata(...) end
--- Реализация sub_1800783E0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:weapons(...) end
--- Реализация sub_1800785C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:weapon_info(...) end
--- Реализация sub_180078D00. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:hitboxes(...) end
--- Реализация sub_180079210. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:hitbox(...) end
--- Реализация sub_180079460. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:flags(...) end
--- Реализация sub_180079500. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:on_ground(...) end
--- Реализация sub_1800795A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:scoped(...) end
--- Реализация sub_1800A7670. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_entity:avatar(...) end

---@class WLIndex_entity
local entity = {}
--- Реализация sub_180050D50. Сигнатура не определена.
---@param ... any
---@return any
function entity.local_pawn(...) end
--- Реализация sub_180050E00. Сигнатура не определена.
---@param ... any
---@return any
function entity.local_controller(...) end
--- Реализация sub_180050E90. Сигнатура не определена.
---@param ... any
---@return any
function entity.get(...) end
--- Реализация sub_180050F80. Сигнатура не определена.
---@param ... any
---@return any
function entity.from_handle(...) end
--- Реализация sub_180051010. Сигнатура не определена.
---@param ... any
---@return any
function entity.players(...) end
--- Реализация sub_180051160. Сигнатура не определена.
---@param ... any
---@return any
function entity.all(...) end
--- Реализация sub_1800A74D0. Сигнатура не определена.
---@param ... any
---@return any
function entity.from_address(...) end
---@type WLIndex_entity
entity = nil

---@class WLIndex_render
local render = {}
--- Реализация sub_1800517F0. Сигнатура не определена.
---@param ... any
---@return any
function render.rect(...) end
--- Реализация sub_180051980. Сигнатура не определена.
---@param ... any
---@return any
function render.rect_filled(...) end
--- Реализация sub_180051AE0. Сигнатура не определена.
---@param ... any
---@return any
function render.gradient(...) end
--- Реализация sub_180051C40. Сигнатура не определена.
---@param ... any
---@return any
function render.line(...) end
--- Реализация sub_180051DA0. Сигнатура не определена.
---@param ... any
---@return any
function render.circle(...) end
--- Реализация sub_180051EA0. Сигнатура не определена.
---@param ... any
---@return any
function render.circle_filled(...) end
--- Реализация sub_180051F70. Сигнатура не определена.
---@param ... any
---@return any
function render.triangle_filled(...) end
--- Реализация sub_1800524E0. Сигнатура не определена.
---@param ... any
---@return any
function render.poly(...) end
--- Реализация sub_1800525C0. Сигнатура не определена.
---@param ... any
---@return any
function render.poly_filled(...) end
--- Реализация sub_180052E40. Сигнатура не определена.
---@param ... any
---@return any
function render.text(...) end
--- Реализация sub_1800533A0. Сигнатура не определена.
---@param ... any
---@return any
function render.text_size(...) end
--- Реализация sub_180053670. Сигнатура не определена.
---@param ... any
---@return any
function render.world_to_screen(...) end
--- Реализация sub_180053720. Сигнатура не определена.
---@param ... any
---@return any
function render.screen_size(...) end
--- Реализация sub_180053770. Сигнатура не определена.
---@param ... any
---@return any
function render.clip_push(...) end
--- Реализация sub_180053890. Сигнатура не определена.
---@param ... any
---@return any
function render.clip_pop(...) end
--- Реализация sub_18005F2A0. Сигнатура не определена.
---@param ... any
---@return any
function render.load_image(...) end
--- Реализация sub_18005F780. Сигнатура не определена.
---@param ... any
---@return any
function render.load_svg(...) end
--- Реализация sub_1800601F0. Сигнатура не определена.
---@param ... any
---@return any
function render.image(...) end
--- Реализация sub_180060410. Сигнатура не определена.
---@param ... any
---@return any
function render.circle_gradient(...) end
--- Реализация sub_1800606D0. Сигнатура не определена.
---@param ... any
---@return any
function render.shadow(...) end
--- Реализация sub_1800A8610. Сигнатура не определена.
---@param ... any
---@return any
function render.scale(...) end
--- Реализация sub_1800A8670. Сигнатура не определена.
---@param ... any
---@return any
function render.menu_scale(...) end
--- Реализация sub_1800A86A0. Сигнатура не определена.
---@param ... any
---@return any
function render.wrap_text(...) end
--- Реализация sub_1800A8990. Сигнатура не определена.
---@param ... any
---@return any
function render.theme(...) end
--- Реализация sub_1800A8B90. Сигнатура не определена.
---@param ... any
---@return any
function render.texture(...) end
--- Реализация sub_1800A8E40. Сигнатура не определена.
---@param ... any
---@return any
function render.rect_filled_multicolor(...) end
--- Реализация sub_1800A8FA0. Сигнатура не определена.
---@param ... any
---@return any
function render.triangle_multicolor(...) end
--- Реализация sub_1800A91C0. Сигнатура не определена.
---@param ... any
---@return any
function render.pie(...) end
--- Реализация sub_1800A9400. Сигнатура не определена.
---@param ... any
---@return any
function render.arc(...) end
--- Реализация sub_1800A95D0. Сигнатура не определена.
---@param ... any
---@return any
function render.blur(...) end
--- Реализация sub_18007AEB0. Сигнатура не определена.
---@param ... any
---@return any
function render.font(...) end
--- Реализация sub_18007C710. Сигнатура не определена.
---@param ... any
---@return any
function render.icon(...) end
--- Реализация sub_18007CA80. Сигнатура не определена.
---@param ... any
---@return any
function render.icons(...) end
---@type WLIndex_render
render = nil

---@class WLIndex_metatable_wl_texture
local metatable_wl_texture = {}
--- Реализация sub_180060180. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_texture:size(...) end

---@class WLIndex_trace
local trace = {}
--- Реализация sub_180060FC0. Сигнатура не определена.
---@param ... any
---@return any
function trace.damage(...) end
--- Реализация sub_1800A64A0. Сигнатура не определена.
---@param ... any
---@return any
function trace.line(...) end
--- Реализация sub_1800A6890. Сигнатура не определена.
---@param ... any
---@return any
function trace.hull(...) end
--- Реализация sub_1800A6A10. Сигнатура не определена.
---@param ... any
---@return any
function trace.bullet(...) end
--- Реализация sub_1800A7060. Сигнатура не определена.
---@param ... any
---@return any
function trace.can_penetrate(...) end
--- Реализация sub_1800A7330. Сигнатура не определена.
---@param ... any
---@return any
function trace.scale_damage(...) end
--- Реализация sub_1800A7430. Сигнатура не определена.
---@param ... any
---@return any
function trace.smoke(...) end
---@type WLIndex_trace
trace = nil

---@class WLIndex_metatable_wl_view
local metatable_wl_view = {}
--- Реализация sub_1800611B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:fov(...) end
--- Реализация sub_180061220. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:set_fov(...) end
--- Реализация sub_1800612E0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:viewmodel_fov(...) end
--- Реализация sub_180061350. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:set_viewmodel_fov(...) end
--- Реализация sub_180079CC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:origin(...) end
--- Реализация sub_180079DD0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:set_origin(...) end
--- Реализация sub_180079E60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:angles(...) end
--- Реализация sub_180079F70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:set_angles(...) end
--- Реализация sub_18007A000. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_view:aspect(...) end

---@class WLIndex_config
local config = {}
--- Реализация sub_180061410. Сигнатура не определена.
---@param ... any
---@return any
function config.get(...) end
--- Реализация sub_180061680. Сигнатура не определена.
---@param ... any
---@return any
function config.set(...) end
--- Реализация sub_180061950. Сигнатура не определена.
---@param ... any
---@return any
function config.keys(...) end
---@type WLIndex_config
config = nil

---@class WLIndex_utils
local utils = {}
--- Реализация sub_180061A20. Сигнатура не определена.
---@param ... any
---@return any
function utils.base64_encode(...) end
--- Реализация sub_180062050. Сигнатура не определена.
---@param ... any
---@return any
function utils.base64_decode(...) end
--- Реализация sub_180062320. Сигнатура не определена.
---@param ... any
---@return any
function utils.fnv1a(...) end
--- Реализация sub_180062390. Сигнатура не определена.
---@param ... any
---@return any
function utils.murmur2(...) end
--- Реализация sub_1800624C0. Сигнатура не определена.
---@param ... any
---@return any
function utils.clipboard_get(...) end
--- Реализация sub_1800626D0. Сигнатура не определена.
---@param ... any
---@return any
function utils.clipboard_set(...) end
--- Реализация sub_18006ED10. Сигнатура не определена.
---@param ... any
---@return any
function utils.time(...) end
--- Реализация sub_18007A0D0. Сигнатура не определена.
---@param ... any
---@return any
function utils.date(...) end
---@type WLIndex_utils
utils = nil

---@class WLIndex_ui
local ui = {}
--- Реализация sub_180059F50. Сигнатура не определена.
---@param ... any
---@return any
function ui.binds(...) end
--- Реализация sub_1800591D0. Сигнатура не определена.
---@param ... any
---@return any
function ui.alpha(...) end
--- Реализация sub_1800591F0. Сигнатура не определена.
---@param ... any
---@return any
function ui.scale(...) end
--- Реализация sub_180059520. Сигнатура не определена.
---@param ... any
---@return any
function ui.position(...) end
--- Реализация sub_180059530. Сигнатура не определена.
---@param ... any
---@return any
function ui.size(...) end
--- Реализация sub_180059540. Сигнатура не определена.
---@param ... any
---@return any
function ui.cursor(...) end
--- Реализация sub_180059690. Сигнатура не определена.
---@param ... any
---@return any
function ui.style(...) end
--- Реализация sub_1800597A0. Сигнатура не определена.
---@param ... any
---@return any
function ui.localize(...) end
--- Реализация sub_180059C00. Сигнатура не определена.
---@param ... any
---@return any
function ui.units(...) end
--- Реализация sub_180054DB0. Сигнатура не определена.
---@param ... any
---@return any
function ui.tab(...) end
--- Реализация sub_180055030. Сигнатура не определена.
---@param ... any
---@return any
function ui.sidebar(...) end
--- Реализация sub_18005A330. Сигнатура не определена.
---@param ... any
---@return any
function ui.find(...) end
--- Реализация sub_180059020. Сигнатура не определена.
---@param ... any
---@return any
function ui.beta_exploits(...) end
---@type WLIndex_ui
ui = nil

---@class WLIndex_metatable_wl_ui
local metatable_wl_ui = {}
--- Реализация sub_18005B5F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:get(...) end
--- Реализация sub_18005B8C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:set(...) end
--- Реализация sub_18005BBA0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:visible(...) end
--- Реализация sub_18005BC60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:depends(...) end
--- Реализация sub_18005BCF0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:callback(...) end
--- Реализация sub_18005BD80. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:items(...) end
--- Реализация sub_18005BF50. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:active(...) end
--- Реализация sub_18005BFD0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:name(...) end
--- Реализация sub_18005B320. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:tooltip(...) end
--- Реализация sub_18005B3C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:inactive(...) end
--- Реализация sub_18005B480. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:image(...) end
--- Реализация sub_18005B510. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:position(...) end
--- Реализация sub_18005B560. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_ui:set_position(...) end

---@class WLIndex_metatable_wl_menu_control
local metatable_wl_menu_control = {}
--- Реализация sub_1800561A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get(...) end
--- Реализация sub_1800561B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_value(...) end
--- Реализация sub_180056470. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_value(...) end
--- Реализация sub_1800561C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_raw_value(...) end
--- Реализация sub_1800565D0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_raw_value(...) end
--- Реализация sub_1800567F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_values(...) end
--- Реализация _DeleteExceptionPtr. Сигнатура не определена. Обработчик требует проверки.
---@param ... any
---@return any
function metatable_wl_menu_control:set_values(...) end
--- Реализация sub_180056810. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_raw_values(...) end
--- Реализация _DeleteExceptionPtr. Сигнатура не определена. Обработчик требует проверки.
---@param ... any
---@return any
function metatable_wl_menu_control:set_raw_values(...) end
--- Реализация sub_180056830. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_effective_values(...) end
--- Реализация sub_180056890. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_default(...) end
--- Реализация sub_180056A90. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_default(...) end
--- Реализация sub_180056DE0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_name(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_name(...) end
--- Реализация sub_180057030. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_visible(...) end
--- Реализация sub_180057100. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_visible(...) end
--- Реализация sub_180057240. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_disabled(...) end
--- Реализация sub_180057310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_disabled(...) end
--- Реализация sub_180056E90. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_tooltip(...) end
--- Реализация sub_180056F50. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_tooltip(...) end
--- Реализация sub_180056FC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_icon(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_icon(...) end
--- Реализация sub_180057440. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_id(...) end
--- Реализация sub_1800574C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_type(...) end
--- Реализация sub_180058380. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_is_down(...) end
--- Реализация sub_1800583F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_parent(...) end
--- Реализация sub_180057590. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_items(...) end
--- Реализация sub_1800577F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_items(...) end
--- Реализация sub_1800576B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_min(...) end
--- Реализация sub_180057AC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_min(...) end
--- Реализация sub_180057750. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_max(...) end
--- Реализация sub_180057AD0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_max(...) end
--- Реализация sub_180058310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_category(...) end
--- Реализация sub_180058310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:set_category(...) end
--- Реализация sub_180058310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:get_categories(...) end
--- Реализация sub_180057AE0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:export(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:import(...) end
--- Реализация sub_180057D90. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:group(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:color_picker(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:color_set(...) end
--- Реализация sub_180056D70. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:color_modes(...) end
--- Реализация sub_1800582A0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:chip(...) end
--- Реализация sub_180058B40. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:add_callback(...) end
--- Реализация sub_180058D20. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_menu_control:remove_callback(...) end

---@class WLIndex_engine
local engine = {}
--- Реализация sub_18005C010. Сигнатура не определена.
---@param ... any
---@return any
function engine.exec(...) end
--- Реализация sub_18005C0B0. Сигнатура не определена.
---@param ... any
---@return any
function engine.in_game(...) end
--- Реализация sub_180053720. Сигнатура не определена.
---@param ... any
---@return any
function engine.screen_size(...) end
--- Реализация sub_180062860. Сигнатура не определена.
---@param ... any
---@return any
function engine.play_sound(...) end
--- Реализация sub_18005C0E0. Сигнатура не определена.
---@param ... any
---@return any
function engine.view_angles(...) end
--- Реализация sub_18005C220. Сигнатура не определена.
---@param ... any
---@return any
function engine.set_view_angles(...) end
--- Реализация sub_1800A5130. Сигнатура не определена.
---@param ... any
---@return any
function engine.post_state(...) end
--- Реализация sub_1800A52C0. Сигнатура не определена.
---@param ... any
---@return any
function engine.simulate(...) end
--- Реализация sub_1800A5D90. Сигнатура не определена.
---@param ... any
---@return any
function engine.max_speed(...) end
--- Реализация sub_1800A5E10. Сигнатура не определена.
---@param ... any
---@return any
function engine.camera_angles(...) end
---@type WLIndex_engine
engine = nil

---@class WLIndex_globals
local globals = {}
--- Реализация sub_18005C330. Сигнатура не определена.
---@param ... any
---@return any
function globals.curtime(...) end
--- Реализация sub_18005C380. Сигнатура не определена.
---@param ... any
---@return any
function globals.realtime(...) end
--- Реализация sub_18005C3F0. Сигнатура не определена.
---@param ... any
---@return any
function globals.frametime(...) end
--- Реализация sub_18005C420. Сигнатура не определена.
---@param ... any
---@return any
function globals.interval(...) end
--- Реализация sub_1800799F0. Сигнатура не определена.
---@param ... any
---@return any
function globals.tickcount(...) end
--- Реализация sub_180079A40. Сигнатура не определена.
---@param ... any
---@return any
function globals.framecount(...) end
---@type WLIndex_globals
globals = nil

---@class WLIndex_input
local input = {}
--- Реализация sub_18005C440. Сигнатура не определена.
---@param ... any
---@return any
function input.key_down(...) end
--- Реализация sub_180062AE0. Сигнатура не определена.
---@param ... any
---@return any
function input.key_name(...) end
--- Реализация sub_18005C4A0. Сигнатура не определена.
---@param ... any
---@return any
function input.cursor(...) end
--- Реализация sub_18005C4F0. Сигнатура не определена.
---@param ... any
---@return any
function input.menu_open(...) end
--- Реализация sub_18007AB90. Сигнатура не определена.
---@param ... any
---@return any
function input.key_pressed(...) end
---@type WLIndex_input
input = nil

---@class WLIndex_client
local client = {}
--- Реализация sub_18005C510. Сигнатура не определена.
---@param ... any
---@return any
function client.delay(...) end
--- Реализация sub_18005C640. Сигнатура не определена.
---@param ... any
---@return any
function client.unload(...) end
--- Реализация sub_18005C690. Сигнатура не определена.
---@param ... any
---@return any
function client.reload(...) end
--- Реализация sub_18005C6E0. Сигнатура не определена.
---@param ... any
---@return any
function client.name(...) end
--- Реализация sub_18005C740. Сигнатура не определена.
---@param ... any
---@return any
function client.insecure(...) end
--- Реализация sub_1800629F0. Сигнатура не определена.
---@param ... any
---@return any
function client.notify(...) end
--- Реализация sub_18007CB40. Сигнатура не определена.
---@param ... any
---@return any
function client.owner(...) end
---@type WLIndex_client
client = nil

---@class WLIndex_log
local log = {}
--- Реализация sub_18005C7A0. Сигнатура не определена.
---@param ... any
---@return any
function log.chat(...) end
--- Реализация sub_18005C920. Сигнатура не определена.
---@param ... any
---@return any
function log.console(...) end
---@type WLIndex_log
log = nil

---@class WLIndex_panorama
local panorama = {}
--- Реализация sub_18005CAA0. Сигнатура не определена.
---@param ... any
---@return any
function panorama.run(...) end
---@type WLIndex_panorama
panorama = nil

---@class WLIndex_schema
local schema = {}
--- Реализация sub_18005CB70. Сигнатура не определена.
---@param ... any
---@return any
function schema.offset(...) end
---@type WLIndex_schema
schema = nil

---@class WLIndex_cvar
local cvar = {}
--- Реализация sub_18005CBE0. Сигнатура не определена.
---@param ... any
---@return any
function cvar.find(...) end
---@type WLIndex_cvar
cvar = nil

---@class WLIndex_metatable_wl_cvar
local metatable_wl_cvar = {}
--- Реализация sub_18005CC60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:get_int(...) end
--- Реализация sub_18005CCA0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:get_float(...) end
--- Реализация sub_18005CCF0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:get_bool(...) end
--- Реализация sub_18005CE00. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:set_int(...) end
--- Реализация sub_18005CE80. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:set_float(...) end
--- Реализация sub_18005CF00. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:set_bool(...) end
--- Реализация sub_18005CF80. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:restore(...) end
--- Реализация sub_18007A070. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cvar:name(...) end

---@class WLIndex_metatable_wl_cmd
local metatable_wl_cmd = {}
--- Реализация sub_18005D050. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:number(...) end
--- Реализация sub_18005D0B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:buttons(...) end
--- Реализация sub_18005D130. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:set_buttons(...) end
--- Реализация sub_18005D1D0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:has(...) end
--- Реализация sub_18005D280. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:press(...) end
--- Реализация sub_18005D320. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:release(...) end
--- Реализация sub_18005D3C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:move(...) end
--- Реализация sub_18005D470. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:set_move(...) end
--- Реализация sub_18005D600. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:view_angles(...) end
--- Реализация sub_18005D750. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:set_view_angles(...) end
--- Реализация sub_18005D850. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:lock_angles(...) end
--- Реализация sub_180079A90. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:rotate_movement(...) end
--- Реализация sub_1800A42D0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:subticks(...) end
--- Реализация sub_1800A4600. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:add_subtick(...) end
--- Реализация sub_1800A49B0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:clear_subticks(...) end
--- Реализация sub_1800A4A30. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:add_button(...) end
--- Реализация sub_1800A4C00. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:remove_button(...) end
--- Реализация sub_1800A4CE0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:upmove(...) end
--- Реализация sub_1800A4D80. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:set_upmove(...) end
--- Реализация sub_1800A4E60. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:predicted(...) end
--- Реализация sub_1800A4EC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:tick(...) end
--- Реализация sub_1800A4F50. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_cmd:mouse_delta(...) end

---@class WLIndex_memory
local memory = {}
--- Реализация sub_18005DA10. Сигнатура не определена.
---@param ... any
---@return any
function memory.read(...) end
--- Реализация sub_18005DA90. Сигнатура не определена.
---@param ... any
---@return any
function memory.write(...) end
--- Реализация sub_18005DB10. Сигнатура не определена.
---@param ... any
---@return any
function memory.find_pattern(...) end
--- Реализация sub_18005DC10. Сигнатура не определена.
---@param ... any
---@return any
function memory.module(...) end
--- Реализация sub_18005DD20. Сигнатура не определена.
---@param ... any
---@return any
function memory.export(...) end
--- Реализация sub_18005DDD0. Сигнатура не определена.
---@param ... any
---@return any
function memory.interface(...) end
---@type WLIndex_memory
memory = nil

---@class WLIndex_file
local file = {}
--- Реализация sub_18005E0D0. Сигнатура не определена.
---@param ... any
---@return any
function file.read(...) end
--- Реализация sub_18005E690. Сигнатура не определена.
---@param ... any
---@return any
function file.write(...) end
--- Реализация sub_18005E6A0. Сигнатура не определена.
---@param ... any
---@return any
function file.append(...) end
--- Реализация sub_18005E6B0. Сигнатура не определена.
---@param ... any
---@return any
function file.exists(...) end
--- Реализация sub_18005E7A0. Сигнатура не определена.
---@param ... any
---@return any
function file.remove(...) end
--- Реализация sub_18005E870. Сигнатура не определена.
---@param ... any
---@return any
function file.list(...) end
---@type WLIndex_file
file = nil

---@class WLIndex_http
local http = {}
--- Реализация sub_180063940. Сигнатура не определена.
---@param ... any
---@return any
function http.get(...) end
--- Реализация sub_180063950. Сигнатура не определена.
---@param ... any
---@return any
function http.post(...) end
---@type WLIndex_http
http = nil

---@class WLIndex_ui_constructor
local ui_constructor = {}
--- Реализация sub_180054230. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.checkbox(...) end
--- Реализация sub_1800542B0. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.slider_int(...) end
--- Реализация sub_180054400. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.slider_float(...) end
--- Реализация sub_180054570. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.combo(...) end
--- Реализация sub_180054680. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.multi_combo(...) end
--- Реализация sub_180054910. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.color(...) end
--- Реализация sub_1800549C0. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.button(...) end
--- Реализация sub_180054A60. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.text(...) end
--- Реализация sub_180054B00. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.label(...) end
--- Реализация sub_180054B60. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.keybind(...) end
--- Реализация sub_18005AD60. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.listbox(...) end
--- Реализация sub_18005AED0. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.divider(...) end
--- Реализация sub_18005AF30. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.image(...) end
--- Реализация sub_18005B070. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.custom(...) end
--- Реализация sub_18005B180. Сигнатура не определена.
---@param ... any
---@return any
function ui_constructor.widget(...) end

---@class WLIndex_game
local game = {}
--- Реализация sub_180079780. Сигнатура не определена.
---@param ... any
---@return any
function game.map(...) end
--- Реализация sub_1800797F0. Сигнатура не определена.
---@param ... any
---@return any
function game.in_menu(...) end
--- Реализация sub_180079810. Сигнатура не определена.
---@param ... any
---@return any
function game.warmup(...) end
--- Реализация sub_180079840. Сигнатура не определена.
---@param ... any
---@return any
function game.freeze_time(...) end
--- Реализация sub_180079870. Сигнатура не определена.
---@param ... any
---@return any
function game.bomb_planted(...) end
--- Реализация sub_1800798A0. Сигнатура не определена.
---@param ... any
---@return any
function game.rounds_played(...) end
--- Реализация sub_1800798D0. Сигнатура не определена.
---@param ... any
---@return any
function game.round_time_left(...) end
--- Реализация sub_1800799C0. Сигнатура не определена.
---@param ... any
---@return any
function game.match_started(...) end
---@type WLIndex_game
game = nil

---@class WLIndex_binds
local binds = {}
--- Реализация sub_18007A1F0. Сигнатура не определена.
---@param ... any
---@return any
function binds.list(...) end
--- Реализация sub_18007A4C0. Сигнатура не определена.
---@param ... any
---@return any
function binds.add(...) end
--- Реализация sub_18007A920. Сигнатура не определена.
---@param ... any
---@return any
function binds.remove(...) end
--- Реализация sub_18007AA90. Сигнатура не определена.
---@param ... any
---@return any
function binds.active(...) end
---@type WLIndex_binds
binds = nil

---@class WLIndex_user
local user = {}
--- Реализация sub_18007B2E0. Сигнатура не определена.
---@param ... any
---@return any
function user.name(...) end
--- Реализация sub_18007B310. Сигнатура не определена.
---@param ... any
---@return any
function user.uid(...) end
--- Реализация sub_18007B330. Сигнатура не определена.
---@param ... any
---@return any
function user.avatar(...) end
--- Реализация sub_18007CCB0. Сигнатура не определена.
---@param ... any
---@return any
function user.info(...) end
---@type WLIndex_user
user = nil

---@class WLIndex_esp
local esp = {}
--- Реализация sub_18007BF20. Сигнатура не определена.
---@param ... any
---@return any
function esp.add_text(...) end
--- Реализация sub_18007BF30. Сигнатура не определена.
---@param ... any
---@return any
function esp.add_bar(...) end
--- Реализация sub_18007BF40. Сигнатура не определена.
---@param ... any
---@return any
function esp.add_icon(...) end
--- Реализация sub_18007C0A0. Сигнатура не определена.
---@param ... any
---@return any
function esp.remove(...) end
---@type WLIndex_esp
esp = nil

---@class WLIndex_metatable_wl_esp_element
local metatable_wl_esp_element = {}
--- Реализация sub_18007C310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_esp_element:remove(...) end
--- Реализация sub_18007C390. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_esp_element:settings(...) end

---@class WLIndex_metatable_wl_font
local metatable_wl_font = {}
--- Реализация sub_18007B280. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_font:loaded(...) end

---@class WLIndex_particle
local particle = {}
--- Реализация sub_18007EC60. Сигнатура не определена.
---@param ... any
---@return any
function particle.create(...) end
--- Реализация sub_18007EF70. Сигнатура не определена.
---@param ... any
---@return any
function particle.precache(...) end
--- Реализация sub_18007EFD0. Сигнатура не определена.
---@param ... any
---@return any
function particle.override(...) end
---@type WLIndex_particle
particle = nil

---@class WLIndex_metatable_wl_particle
local metatable_wl_particle = {}
--- Реализация sub_18007F8F0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:set_point(...) end
--- Реализация sub_18007FB30. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:set_color(...) end
--- Реализация sub_18007FD10. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:bind(...) end
--- Реализация sub_18007FFC0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:path(...) end
--- Реализация sub_180080240. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:lifetime(...) end
--- Реализация sub_180080310. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:destroy(...) end
--- Реализация sub_180080460. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:valid(...) end
--- Реализация sub_1800804C0. Сигнатура не определена.
---@param ... any
---@return any
function metatable_wl_particle:index(...) end

