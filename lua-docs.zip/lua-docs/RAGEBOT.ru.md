# RageBot

## Цель

`ragebot.target() -> wl.entity?` возвращает цель, принятую RageBot в текущем проходе. Если подходящей цели нет или объект уже недоступен, возвращается `nil`.

```lua
local target = ragebot.target()
if target and target:alive() and target:is_enemy() then
    print("RageBot выбрал живого противника")
end
```

Не сохраняйте объект цели после её смерти или смены карты. Для удержания состояния запоминайте адрес, а каждый кадр проверяйте, что такой же pawn всё ещё присутствует среди `entity.players()`.
