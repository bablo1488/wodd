# Engine, cvar и ввод

## Engine

- `engine.in_game() -> boolean` — возвращает `true`, если игра активна.
- `engine.screen_size() -> width, height` — два числа; используется тот же обработчик, что и `render.screen_size()`.
- `engine.view_angles() -> vector?` и `engine.camera_angles() -> vector?` возвращают вектор; при недоступном игровом интерфейсе результатов нет.
- `engine.set_view_angles(angles: vector) -> boolean` принимает таблицу с полями `x`, `y`, `z`, проверяет все три компоненты на конечность и возвращает false при недоступном интерфейсе.
- `engine.max_speed() -> number` возвращает максимальную скорость локального игрока, если она доступна.
- `engine.exec(command: string)` добавляет строку в очередь игровых команд; при достижении предела новые строки игнорируются. Этот метод не сообщает результат исполнения команды.
- `engine.play_sound(name: string)` формирует вызов игрового события звука. Проверяет символы имени и не возвращает результат. Имена звуков зависят от игры.
- `engine.post_state` и `engine.simulate` описаны ниже в разделе о симуляции.

## Консольные переменные

`cvar.find(name: string) -> wl.cvar?` ищет переменную по имени. Если она не найдена, результатов нет, что при присваивании соответствует `nil`.

Методы `wl.cvar`:

- `c:name() -> string?` — имя, если доступно.
- `c:get_int() -> integer`, `c:get_float() -> number`, `c:get_bool() -> boolean` — чтение значения.
- `c:set_int(value: integer)`, `c:set_float(value: number)`, `c:set_bool(value)` — изменение с приведением ко входному типу. Для boolean используется преобразование Lua к логическому значению.
- `c:restore()` — восстанавливает сохранённое исходное значение этого cvar, если оно есть в списке текущего скрипта.

Запись переменной может влиять на игру; используйте подходящий тип и проверяйте её наличие.

## Имена клавиш

`input.key_name(code: integer) -> string?` обрабатывает Windows-коды. Для 1, 2, 4, 5, 6 возвращает соответственно `mouse 1` … `mouse 5`. Остальные имена запрашиваются через Windows; если код не распознан, функция не возвращает результат.

## Снимок и симуляция движения

`engine.post_state() -> table` формирует таблицу с `valid`, `status`, `flags`, `on_ground`, `move_type`, `landed_frac`, `landed`, `tick`, `origin`, `velocity`. Поля `origin` и `velocity` — векторы. 

`engine.simulate(ticks: integer, callback?: function) -> table[]?` работает только внутри `createmove`, число шагов ограничивается 1–64. Функция возвращает массив результатов по шагам; каждая запись включает `valid`, `flags`, `on_ground`, `move_type`, `origin`, `velocity`, `jumped`, `landed`, `landed_frac`, `duck`. Если нужные игровые данные недоступны, функция может не вернуть результат. Форма callback и поддерживаемые поля приведены ниже; 

### Callback симуляции

По обработчику callback вызывается как `callback(step, input)`: первым передаётся целый номер шага, вторым — изменяемая таблица с числовыми полями `buttons`, `forward`, `left`, `pitch`, `yaw`. После возврата код считывает изменённые поля обратно; если поле не число, сохраняет прежнее значение. Также можно задать `input.events` — массив таблиц с `when` (ограничивается 0–1), `button` и `pressed` (по умолчанию true); учитываются не более восьми таких записей на шаг. `nil` или истинный результат callback передаётся движку как true; false — как false. Влияние этого результата на продолжение симуляции нужно проверить.

```lua
-- Пример callback.
events.on("createmove", function(cmd)
    local prediction = engine.simulate(3, function(step, input)
        input.forward = 0
        input.left = 0
        return true
    end)
    if prediction then print("simulated steps:", #prediction) end
end)
```

