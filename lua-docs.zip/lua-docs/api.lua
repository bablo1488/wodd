---@meta
-- Только подсказки редактора. Этот файл нельзя загружать как игровой скрипт.
-- Извлечено из DLL статически; без проверки в игре.

---@class WLCommand
local Command = {}
---@return number
function Command:number() end
---@return number
function Command:buttons() end
---@param mask number
function Command:set_buttons(mask) end
---@param mask number
---@return boolean
function Command:has(mask) end
---@param mask number
function Command:press(mask) end
---@param mask number
function Command:release(mask) end
---@return number? first
---@return number? second
function Command:move() end
---@param first number
---@param second number
---@param option? boolean Семантика не установлена.
function Command:set_move(first, second, option) end
---@return any? angles Представление требует проверки.
function Command:view_angles() end
---@param angles any Представление требует проверки.
function Command:set_view_angles(angles) end
function Command:lock_angles() end

---@class WLEntity
local Entity = {}
---@return number
function Entity:health() end
---@return any vector
function Entity:velocity() end

---@class WLUIControl
local Control = {}
---@param index? integer Для multiselect, индексация с нуля.
---@return any value
---@return string? label
function Control:get(index) end
---@param value any
---@param selected? boolean Для multiselect.
function Control:set(value, selected) end

---@class WLTab
local Tab = {}
---@param name string
---@param min integer
---@param max integer
---@param default? integer
---@param format? string
---@return WLUIControl
function Tab.slider_int(name, min, max, default, format) end

---@class WLEvents
local Events = {}
---@param name string
---@param callback function
---@return integer id
function Events.on(name, callback) end
---@param id integer
---@return boolean
function Events.off(id) end

---@class WLUI
local UI = {}
---@param name string
---@return WLTab
function UI.tab(name) end

---@class WLEntityAPI
local EntityAPI = {}
---@return WLEntity?
function EntityAPI.local_pawn() end

---@type WLEvents
events = nil
---@type WLUI
ui = nil
---@type WLEntityAPI
entity = nil

---@class WLColor
---@field r? number 0..255, по умолчанию 255
---@field g? number 0..255, по умолчанию 255
---@field b? number 0..255, по умолчанию 255
---@field a? number 0..255, по умолчанию 255

---@class WLVector
---@field x? number
---@field y? number
---@field z? number

---@param name string
---@param default? boolean
---@return WLUIControl
function Tab.checkbox(name, default) end
---@param name string
---@param min number
---@param max number
---@param default? number
---@param format? string
---@return WLUIControl
function Tab.slider_float(name, min, max, default, format) end
---@param name string
---@param items string[]
---@param default_index? integer Начиная с нуля.
---@return WLUIControl
function Tab.combo(name, items, default_index) end
---@param name string
---@param items string[]
---@param defaults? table
---@return WLUIControl
function Tab.multi_combo(name, items, defaults) end
---@param name string
---@param items string[]
---@param rows? integer 2..16, по умолчанию 5.
---@param default_index? integer Начиная с нуля.
---@return WLUIControl
function Tab.listbox(name, items, rows, default_index) end
---@param name string
---@param key? integer
---@return WLUIControl
function Tab.keybind(name, key) end
---@param name string
---@param callback? function
---@return WLUIControl
function Tab.button(name, callback) end
---@param name string
---@return WLUIControl
function Tab.label(name) end
---@return boolean
function Control:active() end
---@param callback? function
---@return WLUIControl
function Control:callback(callback) end
---@param items string[]
function Control:items(items) end

---@class WLRender
local Render = {}
---@param x1 number
---@param y1 number
---@param x2 number
---@param y2 number
---@param color WLColor
---@param thickness? number
function Render.line(x1, y1, x2, y2, color, thickness) end
---@return number width
---@return number height
function Render.screen_size() end
---@class WLClient
local Client = {}
---@param seconds number
---@param callback function
function Client.delay(seconds, callback) end
---@type WLRender
render = nil
---@type WLClient
client = nil

---@class WLEvent
local Event = {}
---@return string
function Event:name() end
---@param key string
---@return integer
function Event:get_int(key) end
---@param key string
---@return number
function Event:get_float(key) end
---@param key string
---@return boolean
function Event:get_bool(key) end
---@param key string
---@return string
function Event:get_string(key) end
---@param key string
---@return WLEntity?
function Event:get_controller(key) end
---@param key string
---@return WLEntity?
function Event:get_pawn(key) end

---@return boolean
function Entity:alive() end
---@return boolean
function Entity:on_ground() end
---@return boolean
function Entity:is_enemy() end
---@return boolean
function Entity:is_local() end
---@return integer
function Entity:armor() end
---@return integer
function Entity:team() end
---@return string
function Entity:name() end
---@return string
function Entity:class_name() end
---@return integer
function Entity:flags() end
---@return boolean
function Entity:scoped() end
---@param index integer
---@return WLVector?
function Entity:bone(index) end
---@param class_or_offset string|number
---@param field_or_type string
---@param value_type? string
---@return any
function Entity:get(class_or_offset, field_or_type, value_type) end
---@param ... any Принимает (class, field, type, value) или (offset, type, value); требует insecure.
function Entity:set(...) end
---@param index integer
---@return WLEntity?
function EntityAPI.get(index) end
---@param handle number
---@return WLEntity?
function EntityAPI.from_handle(handle) end
---@return table[]
function EntityAPI.players() end
---@param class_name? string
---@return WLEntity[]
function EntityAPI.all(class_name) end
---@param position WLVector
---@return number? x
---@return number? y
function Render.world_to_screen(position) end

---@class WLFont
local Font = {}
---@return boolean
function Font:loaded() end
---@class WLTexture
local Texture = {}
---@return integer? width
---@return integer? height
function Texture:size() end
---@param name string
---@param size? number
---@return WLFont
function Render.font(name, size) end
---@param name string
---@param height? integer
---@return WLTexture? texture
---@return string? error
function Render.icon(name, height) end
---@return string[]
function Render.icons() end
---@param text string
---@param flags? string
---@param size? number
---@param font? WLFont
---@return number? width
---@return number? height
function Render.text_size(text, flags, size, font) end
---@param x number
---@param y number
---@param color WLColor
---@param text string
---@param flags? string
---@param size? number
---@param font? WLFont
function Render.text(x, y, color, text, flags, size, font) end

---@class WLSubtick
---@field index? number
---@field when number
---@field button? number
---@field pressed? boolean
---@field forward? number
---@field left? number
---@field pitch? number
---@field yaw? number
---@field is_button? boolean
---@return WLSubtick[]
function Command:subticks() end
---@param data WLSubtick
---@return boolean
function Command:add_subtick(data) end
---@return number
function Command:upmove() end
---@param value number Ограничивается диапазоном -1..1.
function Command:set_upmove(value) end
---@return boolean
function Command:predicted() end
---@return integer
function Command:tick() end
---@return number x
---@return number y
function Command:mouse_delta() end
---@param angle number
---@param sync_buttons? boolean
function Command:rotate_movement(angle, sync_buttons) end

---@class WLView
local View = {}
---@return number
function View:fov() end
---@param value number Ограничивается диапазоном 1..179.
function View:set_fov(value) end
---@return number
function View:viewmodel_fov() end
---@param value number Ограничивается диапазоном 1..179.
function View:set_viewmodel_fov(value) end
---@return WLVector
function View:origin() end
---@param value WLVector
function View:set_origin(value) end
---@return WLVector
function View:angles() end
---@param value WLVector
function View:set_angles(value) end
---@return number
function View:aspect() end

---@class WLTraceResult
---@field hit boolean
---@field fraction number
---@field position WLVector
---@field normal WLVector
---@field entity? WLEntity
---@field start_solid? boolean
---@field friction? number
---@class WLTraceOptions
---@field skip? WLEntity
---@field mask? number
---@field layer? number
---@field type? number
---@field mins? WLVector
---@field maxs? WLVector
---@class WLTraceAPI
local Trace = {}
---@param start WLVector
---@param finish WLVector
---@param options? WLTraceOptions|WLEntity
---@return WLTraceResult
function Trace.line(start, finish, options) end
---@param start WLVector
---@param finish WLVector
---@param mins WLVector
---@param maxs WLVector
---@param options? WLTraceOptions|WLEntity
---@return WLTraceResult
function Trace.hull(start, finish, mins, maxs, options) end
---@param target WLEntity
---@param position WLVector
---@param hitgroup? integer
---@param start? WLVector
---@return number?
function Trace.damage(target, position, hitgroup, start) end
---@type WLTraceAPI
trace = nil

---@class WLParticle
local Particle = {}
---@param index integer
---@param value WLVector|number
---@param y? number
---@param z? number
---@return WLParticle
function Particle:set_point(index, value, y, z) end
---@param index integer
---@param color WLColor
---@return WLParticle
function Particle:set_color(index, color) end
---@param index integer
---@param entity WLEntity
---@param attachment? integer
---@param point_name? string
---@return WLParticle
function Particle:bind(index, entity, attachment, point_name) end
---@param points WLVector[]
---@return WLParticle
function Particle:path(points) end
---@param seconds number
---@return WLParticle
function Particle:lifetime(seconds) end
function Particle:destroy() end
---@return boolean
function Particle:valid() end
---@return integer?
function Particle:index() end
---@class WLParticleAPI
local ParticleAPI = {}
---@param resource string
---@param attachment? integer
---@return WLParticle
function ParticleAPI.create(resource, attachment) end
---@param resource string
function ParticleAPI.precache(resource) end
---@type WLParticleAPI
particle = nil

---@class WLVector
---@field x number
---@field y number
---@field z number
local Vector = {}
---@return number
function Vector:length() end
---@return number
function Vector:length_sqr() end
---@return number
function Vector:length2d() end
---@param other WLVector
---@return number
function Vector:dist(other) end
---@param other WLVector
---@return number
function Vector:dist2d(other) end
---@param other WLVector
---@return number
function Vector:dot(other) end
---@param other WLVector
---@return WLVector
function Vector:cross(other) end
---@return WLVector
function Vector:normalized() end
---@return WLVector
function Vector:clone() end
---@return number x
---@return number y
---@return number z
function Vector:unpack() end
---@return boolean
function Vector:is_zero() end
---@param other WLVector
---@param t number
---@return WLVector
function Vector:lerp(other, t) end
---@return WLVector
function Vector:forward() end
---@return WLVector forward
---@return WLVector right
---@return WLVector up
function Vector:angle_vectors() end
---@return WLVector
function Vector:angles() end
---@param x? number
---@param y? number
---@param z? number
---@return WLVector
function vector(x, y, z) end

---@class WLColor
---@field r number
---@field g number
---@field b number
---@field a number
local Color = {}
---@param a number
---@return WLColor
function Color:alpha(a) end
---@param other WLColor
---@param t number
---@return WLColor
function Color:lerp(other, t) end
---@return number r
---@return number g
---@return number b
---@return number a
function Color:unpack() end
---@return string
function Color:hex() end
---@return number h
---@return number s
---@return number v
function Color:hsv() end
---@param f? number
---@return WLColor
function Color:darken(f) end
---@param f? number
---@return WLColor
function Color:lighten(f) end
---@return WLColor
function Color:gray() end
---@param r? number|string
---@param g? number
---@param b? number
---@param a? number
---@return WLColor
function color(r, g, b, a) end
---@param h number
---@param s number
---@param v number
---@param a? number
---@return WLColor
function color_hsv(h,s,v,a) end
---@param p? number
---@param a? number
---@return WLColor
function color_percent(p,a) end

---@class WLJson
---@field null table
local JSON = {}
---@param value any
---@return string
function JSON.encode(value) end
---@param text string
---@return any value
---@return string? error
function JSON.decode(text) end
---@type WLJson
json = nil

---@class WLHttpResponse
---@field ok boolean
---@field status integer
---@field body string
---@field error? string
---@field headers table<string,string>
---@class WLHttpOptions
---@field timeout? number Seconds, limited to 1..30.
---@field headers? table<string,string>
---@class WLHttp
local Http = {}
---@param url string
---@param options_or_callback WLHttpOptions|fun(response:WLHttpResponse)
---@param callback? fun(response:WLHttpResponse)
---@return boolean queued
---@return string? error
function Http.get(url, options_or_callback, callback) end
---@param url string
---@param body string
---@param options_or_callback WLHttpOptions|fun(response:WLHttpResponse)
---@param callback? fun(response:WLHttpResponse)
---@return boolean queued
---@return string? error
function Http.post(url, body, options_or_callback, callback) end
---@type WLHttp
http = nil
