# Ввод, клиент и уведомления

## Ввод `input`

- `input.key_down(code: integer) -> boolean` проверяет числовой код клавиши в диапазоне 1–255; вне диапазона возвращает `false`.
- `input.key_pressed(code: integer) -> boolean` возвращает `true` при новом нажатии указанной клавиши.
- `input.cursor() -> number, number` возвращает два числа координат курсора.
- `input.menu_open() -> boolean` читает флаг открытого меню.
- `input.key_name` возвращает строковое имя клавиши по её коду.

## Скрипт `client`

- `client.name() -> string` возвращает имя текущего скрипта.
- `client.insecure() -> boolean` возвращает сохранённый флаг insecure текущего скрипта.
- `client.delay(seconds: number, callback: function)` добавляет callback в очередь; отрицательная задержка ограничивается нулём. Вызов исполняется при обслуживании очереди клиента, а не обязательно в точный момент времени.
- `client.unload()` выставляет флаг выгрузки текущего скрипта.
- `client.reload()` выставляет флаг перезагрузки текущего скрипта.
- `client.notify(message: string, title?: string)` создаёт уведомление; заголовок по умолчанию — имя скрипта.
- `client.owner` возвращает сведения о владельце скрипта.

```lua
-- Пример использования.
client.notify("Script loaded")
client.delay(1, function()
    print("Script:", client.name())
end)
```

`log.chat(...)` и `log.console(...)` выводят переданный текст в игровой чат и консоль соответственно.
